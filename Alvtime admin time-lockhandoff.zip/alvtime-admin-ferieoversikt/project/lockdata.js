/* Timelås — sample data: customers with per-customer lock state and last registered hours. */
(function () {
  const C = [
    // name, lastRegistered (siste dag med registrerte timer), lockedThrough, excluded, note
    ['Skatteetaten', '2026-06-09', '2026-04-30'],
    ['NAV', '2026-06-10', '2026-04-30'],
    ['Vy Group', '2026-06-05', '2026-03-31'],
    ['Statens vegvesen', '2026-06-09', '2026-04-30'],
    ['Ruter', '2026-05-29', '2026-04-30'],
    ['Posten Bring', '2026-06-08', '2026-04-30'],
    ['Kartverket', '2026-06-10', '2026-04-30'],
    ['Norges Bank', '2026-05-13', '2026-04-30'],
    ['Politiet IT', '2026-06-03', null],
    ['Oslo kommune', '2026-06-09', '2026-04-30'],
    ['Helse Sør-Øst', '2026-04-24', '2026-04-30'],
    ['Entur', '2026-06-02', '2026-02-28', true, 'Etterfakturering, avtalt med kunde'],
    ['Sopra Bank', '2026-02-27', '2026-02-28'],
    ['Gjensidige', '2026-06-04', '2026-05-31'],
    ['Alv internt', '2026-06-10', null, true, 'Interntid – faktureres ikke'],
    ['Bergen kommune', '2026-01-30', '2026-01-31'],
    ['Nordea Liv', '2025-11-28', '2025-12-31'],
    ['Telenor Maritime', '2026-03-31', '2026-03-31'],
    ['Fiskeridirektoratet', '2025-09-30', '2025-09-30'],
    ['Avinor', '2026-02-13', '2026-02-28'],
  ];

  window.LOCK = {
    customers: C.map(([name, lastRegistered, lockedThrough, excluded, note], i) => ({
      id: 100 + i, name, lastRegistered, lockedThrough,
      excluded: !!excluded, note: note || null,
      lockedBy: lockedThrough ? 'Pål Bøckmann' : null,
      lockedAt: lockedThrough ? '2026-05-12' : null,
    })),
    lockedThrough: '2026-04-30',
    lockedBy: 'Pål Bøckmann',
    lockedAt: '2026-05-12',
  };
})();
