/* Timelås — lock registered hours up to a date, in bulk or per customer. */
const LFMT = window.FERIE_FMT;
const LTODAY = window.FERIE_TODAY;

function endOfPrevMonth(d) { return new Date(d.getFullYear(), d.getMonth(), 0); }
function endOfPrevQuarter(d) { const q = Math.floor(d.getMonth() / 3); return new Date(d.getFullYear(), q * 3, 0); }
function maxIso(list) { return list.filter(Boolean).sort().slice(-1)[0] || null; }

const fieldStyle = {
  padding: '11px 14px', border: '1px solid var(--border-strong)', borderRadius: 'var(--radius)',
  background: 'var(--card)', color: 'var(--slate)', fontSize: 15, fontFamily: 'inherit',
};
const btnBase = {
  fontFamily: 'inherit', fontSize: 15, borderRadius: 'var(--radius)', cursor: 'pointer',
  padding: '11px 20px', border: '1px solid transparent', whiteSpace: 'nowrap',
};

function LockButton({ children, kind = 'primary', onClick, disabled, small }) {
  const kinds = {
    primary: { background: 'var(--sage-deep)', color: '#fff', fontWeight: 700 },
    ghost: { background: 'transparent', color: 'var(--slate)', borderColor: 'var(--border-strong)' },
    danger: { background: 'transparent', color: 'var(--danger)', borderColor: '#dcc0b6' },
  }[kind];
  return (
    <button onClick={onClick} disabled={disabled}
      style={{ ...btnBase, ...kinds, ...(small ? { padding: '6px 12px', fontSize: 13.5 } : null), opacity: disabled ? .45 : 1, cursor: disabled ? 'not-allowed' : 'pointer' }}>
      {children}
    </button>
  );
}

function LockForm({ st, target, setTarget, onLock, onUnlock }) {
  const tgt = target ? LFMT.parse(target) : null;
  const included = st.customers.filter(c => !c.excluded);
  const quick = [
    ['I dag', LFMT.iso(LTODAY)],
    ['Ut forrige måned', LFMT.iso(endOfPrevMonth(LTODAY))],
  ];
  return (
    <section style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '26px 28px 24px', boxShadow: 'var(--shadow)', marginBottom: 34 }}>
      <h2 style={{ fontSize: 24 }}>Lås alle kunder</h2>
      <div style={{ color: 'var(--slate-soft)', fontSize: 15, marginTop: 6, maxWidth: 640 }}>
        Alle timer til og med valgt dato låses for redigering. Ekskluderte kunder hoppes over og beholder sin egen låsedato.
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'flex-end', gap: 18, marginTop: 22 }}>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
          <span style={{ fontSize: 12.5, textTransform: 'uppercase', letterSpacing: '.7px', color: 'var(--slate-soft)', fontWeight: 700 }}>Lås til og med</span>
          <input type="date" value={target} min="2026-01-01" max={LFMT.iso(LTODAY)}
            onChange={e => setTarget(e.target.value)} style={{ ...fieldStyle, width: 190 }} />
        </label>
        <div style={{ display: 'flex', gap: 10, paddingBottom: 1 }}>
          {quick.map(([label, iso]) => (
            <button key={label} onClick={() => setTarget(iso)}
              style={{ ...btnBase, padding: '10px 15px', fontSize: 14, background: target === iso ? 'var(--card-2)' : 'transparent', color: target === iso ? 'var(--ink)' : 'var(--slate)', borderColor: target === iso ? 'var(--border-strong)' : 'var(--border)', fontWeight: target === iso ? 700 : 400 }}>
              {label}
            </button>
          ))}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginTop: 24, paddingTop: 20, borderTop: '1px solid var(--border)', flexWrap: 'wrap' }}>
        <LockButton onClick={onLock} disabled={!tgt}>Lås timer</LockButton>
        <div style={{ fontSize: 14.5, color: 'var(--slate-soft)', flex: 1, minWidth: 240 }}>
          {tgt ? <>Setter låsedato <b style={{ color: 'var(--ink)' }}>{LFMT.long(tgt)}</b> for {included.length} kunder.</> : 'Velg en dato.'}
        </div>
        <button onClick={onUnlock} style={{ ...btnBase, background: 'none', border: 'none', color: 'var(--gold)', padding: '11px 0', textDecoration: 'underline' }}>Åpne opp alle igjen</button>
      </div>
    </section>
  );
}

// ── Per-customer row ─────────────────────────
function CustomerRow({ c, first, onSetDate, onUnlock, onToggleExclude }) {
  const [editing, setEditing] = React.useState(false);
  const [draft, setDraft] = React.useState(c.lockedThrough || LFMT.iso(endOfPrevMonth(LTODAY)));
  const locked = !!c.lockedThrough;
  const save = () => { onSetDate(c.id, draft); setEditing(false); };
  return (
    <tr style={{ borderTop: first ? 'none' : '1px solid var(--border)', background: c.excluded ? 'var(--plan-bg)' : 'transparent' }}>
      <td style={{ padding: '14px 18px', width: 46 }}>
        <span onClick={() => onToggleExclude(c.id)} title="Ekskluder fra masselås" style={{
          width: 19, height: 19, borderRadius: 4, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
          border: '1.5px solid ' + (c.excluded ? 'var(--plan)' : 'var(--border-strong)'), background: c.excluded ? 'var(--plan)' : 'var(--card)',
          color: '#fff', fontSize: 13, lineHeight: 1,
        }}>{c.excluded ? '✓' : ''}</span>
      </td>
      <td style={{ padding: '14px 18px' }}>
        <div style={{ fontWeight: 700, color: 'var(--ink)', fontSize: 16 }}>{c.name}</div>
        {c.excluded && <div style={{ fontSize: 13, color: 'var(--plan)', marginTop: 2 }}>{c.note || 'Ekskludert fra masselås'}</div>}
      </td>
      <td style={{ padding: '14px 18px' }}>
        {editing ? (
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input type="date" value={draft} max={LFMT.iso(LTODAY)} onChange={e => setDraft(e.target.value)}
              autoFocus style={{ ...fieldStyle, padding: '7px 10px', fontSize: 14, width: 168 }} />
            <LockButton small onClick={save}>Lagre</LockButton>
            <LockButton small kind="ghost" onClick={() => setEditing(false)}>Avbryt</LockButton>
          </div>
        ) : locked ? (
          <div>
            <div style={{ color: 'var(--ink)', fontSize: 15.5 }}>{LFMT.long(LFMT.parse(c.lockedThrough))}</div>
            <div style={{ fontSize: 13, color: 'var(--slate-soft)', marginTop: 2 }}>
              Låst {LFMT.medium(LFMT.parse(c.lockedAt))} av {c.lockedBy}
            </div>
          </div>
        ) : (
          <span style={{ color: 'var(--slate-soft)', fontSize: 15.5 }}>Ikke låst</span>
        )}
      </td>
      <td style={{ padding: '14px 18px', width: 120 }}>
        <span className={'pill ' + (locked ? 'taken' : 'free')}>{locked ? 'Låst' : 'Åpen'}</span>
      </td>
      <td style={{ padding: '14px 18px', textAlign: 'right', whiteSpace: 'nowrap', width: 210 }}>
        {!editing && (
          <span style={{ display: 'inline-flex', gap: 8, justifyContent: 'flex-end' }}>
            <LockButton small kind="ghost" onClick={() => { setDraft(c.lockedThrough || LFMT.iso(endOfPrevMonth(LTODAY))); setEditing(true); }}>
              {locked ? 'Endre dato' : 'Lås til dato'}
            </LockButton>
            {locked && <LockButton small kind="danger" onClick={() => onUnlock(c.id)}>Lås opp</LockButton>}
          </span>
        )}
      </td>
    </tr>
  );
}

function Modal({ children, onClose }) {
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(36,63,77,.42)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 40 }}>
      <div onClick={e => e.stopPropagation()} style={{ background: 'var(--card)', border: '1px solid var(--border-strong)', borderRadius: 8, padding: '30px 32px', width: 520, maxWidth: '92vw', boxShadow: '0 18px 44px rgba(36,63,77,.24)' }}>
        {children}
      </div>
    </div>
  );
}

function SumRow({ label, value, plan }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 20, padding: '5px 0', fontSize: 15 }}>
      <span style={{ color: 'var(--slate-soft)' }}>{label}</span>
      <b style={{ color: plan ? 'var(--plan)' : 'var(--ink)', textAlign: 'right' }}>{value}</b>
    </div>
  );
}

function LockPage() {
  const st0 = window.LOCK;
  const [state, setState] = React.useState({ ...st0 });
  const [target, setTarget] = React.useState(LFMT.iso(endOfPrevMonth(LTODAY)));
  const [q, setQ] = React.useState('');
  const [modal, setModal] = React.useState(null);   // 'lock' | 'unlock' | 'done'
  const [unlockDate, setUnlockDate] = React.useState(LFMT.iso(endOfPrevQuarter(LTODAY)));
  const [months] = React.useState(2);
  const [showAll, setShowAll] = React.useState(false);

  const ME = 'Pål Bøckmann';
  const NOW = LFMT.iso(LTODAY);
  const included = state.customers.filter(c => !c.excluded);
  const excluded = state.customers.filter(c => c.excluded);

  const cutoff = new Date(LTODAY.getFullYear(), LTODAY.getMonth() - months, 1);
  const cutoffIso = LFMT.iso(cutoff);
  const isRecent = (c) => c.excluded || (c.lastRegistered && c.lastRegistered >= cutoffIso);
  const matched = state.customers.filter(c => c.name.toLowerCase().includes(q.toLowerCase()));
  const filtering = !showAll && !q;
  const rows = filtering ? matched.filter(isRecent) : matched;
  const hiddenCount = matched.length - rows.length;

  const patch = (id, fields) => (s) => ({ ...s, customers: s.customers.map(c => c.id === id ? { ...c, ...fields } : c) });

  const toggleExclude = (id) => setState(s => ({ ...s, customers: s.customers.map(c => c.id === id ? { ...c, excluded: !c.excluded } : c) }));

  const setCustomerDate = (id, date) => setState(s => {
    const c = s.customers.find(x => x.id === id);
    return patch(c.id, { lockedThrough: date, lockedBy: ME, lockedAt: NOW })(s);
  });

  const unlockCustomer = (id) => setState(s => {
    const c = s.customers.find(x => x.id === id);
    return patch(c.id, { lockedThrough: null, lockedBy: null, lockedAt: null })(s);
  });

  const commitLock = () => {
    setState(s => {
      return { ...s, lockedThrough: target, lockedBy: ME, lockedAt: NOW,
        customers: s.customers.map(c => c.excluded ? c : { ...c, lockedThrough: target, lockedBy: ME, lockedAt: NOW }) };
    });
    setModal('done');
  };

  const commitUnlockAll = () => {
    setState(s => {
      return { ...s, lockedThrough: unlockDate, lockedAt: NOW, lockedBy: ME,
        customers: s.customers.map(c => (c.lockedThrough && c.lockedThrough > unlockDate) ? { ...c, lockedThrough: unlockDate, lockedBy: ME, lockedAt: NOW } : c) };
    });
    setModal(null);
  };

  const th = (label, align, width) => (
    <th style={{ textAlign: align || 'left', padding: '0 18px 12px', fontSize: 12.5, fontWeight: 700, color: 'var(--slate-soft)', textTransform: 'uppercase', letterSpacing: '.7px', whiteSpace: 'nowrap', width }}>{label}</th>
  );

  return (
    <div className="page">
      <h1 className="pagetitle">Timelås</h1>
      <div className="subtitle">Lås registrerte timer etter at faktura er sendt, så de ikke kan endres i etterkant.</div>
      <div style={{ height: 28 }}></div>

      <LockForm st={state} target={target} setTarget={setTarget} onLock={() => setModal('lock')} onUnlock={() => setModal('unlock')} />

      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 20, marginBottom: 16, flexWrap: 'wrap' }}>
        <div>
          <h2 style={{ fontSize: 24 }}>Kunder</h2>
          <div style={{ color: 'var(--slate-soft)', fontSize: 15, marginTop: 6 }}>
            Lås eller lås opp enkeltkunder. Avkryssede kunder hoppes over ved masselås.
          </div>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <div style={{ position: 'relative', width: 260 }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--slate-soft)' }}>⌕</span>
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Søk etter kunde" style={{ ...fieldStyle, width: '100%', paddingLeft: 38 }} />
        </div>
        </div>
      </div>

      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', boxShadow: 'var(--shadow)' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr style={{ borderBottom: '1px solid var(--border)' }}>
            <th style={{ padding: '16px 18px 12px', width: 46 }}></th>
            {th('Kunde')}{th('Låst til og med')}{th('Status')}{th('', 'right')}
          </tr></thead>
          <tbody>
            {rows.map((c, i) => (
              <CustomerRow key={c.id} c={c} first={i === 0} onSetDate={setCustomerDate} onUnlock={unlockCustomer} onToggleExclude={toggleExclude} />
            ))}
          </tbody>
        </table>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, padding: '14px 18px', borderTop: '1px solid var(--border)', fontSize: 14, color: 'var(--slate-soft)', flexWrap: 'wrap' }}>
          <span>
            Viser {rows.length} av {state.customers.length} kunder
            {filtering && <> — med timer registrert etter {LFMT.medium(cutoff)}</>}
          </span>
        </div>
      </div>

      {modal === 'lock' && (
        <Modal onClose={() => setModal(null)}>
          <h2 style={{ fontSize: 26 }}>Lås timer til og med {LFMT.long(LFMT.parse(target))}?</h2>
          <div style={{ background: 'var(--card-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '16px 18px', margin: '20px 0 18px' }}>
            <SumRow label="Kunder som låses" value={`${included.length} kunder`} />
            <SumRow label="Holdes åpne" value={excluded.length ? excluded.map(c => c.name).join(', ') : 'ingen'} plan />
          </div>
          <div style={{ fontSize: 14.5, color: 'var(--slate-soft)', marginBottom: 22 }}>
            Ansatte kan ikke endre eller slette låste timer. Enkeltkunder kan låses opp igjen etterpå.
          </div>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <LockButton kind="ghost" onClick={() => setModal(null)}>Avbryt</LockButton>
            <LockButton onClick={commitLock}>Lås {included.length} kunder</LockButton>
          </div>
        </Modal>
      )}

      {modal === 'unlock' && (
        <Modal onClose={() => setModal(null)}>
          <h2 style={{ fontSize: 26 }}>Åpne opp alle igjen</h2>
          <div style={{ fontSize: 15, color: 'var(--slate-soft)', margin: '10px 0 20px' }}>
            Flytt låsedatoen bakover for alle kunder som er låst lenger frem. Timer etter den nye datoen blir redigerbare igjen.
          </div>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            <span style={{ fontSize: 12.5, textTransform: 'uppercase', letterSpacing: '.7px', color: 'var(--slate-soft)', fontWeight: 700 }}>Ny låsedato</span>
            <input type="date" value={unlockDate} max={LFMT.iso(LTODAY)} onChange={e => setUnlockDate(e.target.value)} style={{ ...fieldStyle, width: 190 }} />
          </label>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 26 }}>
            <LockButton kind="ghost" onClick={() => setModal(null)}>Avbryt</LockButton>
            <LockButton kind="danger" onClick={commitUnlockAll}>Åpne opp</LockButton>
          </div>
        </Modal>
      )}

      {modal === 'done' && (
        <Modal onClose={() => setModal(null)}>
          <h2 style={{ fontSize: 26 }}>Timene er låst</h2>
          <div style={{ fontSize: 15.5, color: 'var(--slate)', margin: '12px 0 24px' }}>
            Alt til og med <b>{LFMT.long(LFMT.parse(state.lockedThrough))}</b> er nå låst for {included.length} kunder.
            {excluded.length > 0 && <> {excluded.length} {excluded.length === 1 ? 'kunde' : 'kunder'} står fortsatt åpne.</>}
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <LockButton onClick={() => setModal(null)}>Lukk</LockButton>
          </div>
        </Modal>
      )}
    </div>
  );
}

Object.assign(window, { LockPage });
