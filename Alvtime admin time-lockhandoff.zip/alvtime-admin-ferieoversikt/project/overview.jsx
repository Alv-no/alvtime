/* Ferie — all-employees overview. Two directions: "tabell" and "kort".
   Shared UI helpers are exported to window for detail.jsx. */

const FMT = window.FERIE_FMT;
const TODAY = window.FERIE_TODAY;

// Norwegian number: 4 -> "4", 4.5 -> "4,5"
function nDays(n) {
  if (n == null) return '–';
  return (Math.round(n * 10) / 10).toString().replace('.', ',');
}

function Avatar({ emp, size = 44 }) {
  const fs = Math.round(size * 0.4);
  return (
    <div className="avatar" style={{ width: size, height: size, fontSize: fs, position: 'relative' }}>
      <span>{emp.initials}</span>
      {emp.photo && <img src={`https://i.pravatar.cc/120?u=alv${emp.id}`} alt=""
        onError={e => { e.target.style.display = 'none'; }}
        style={{ position: 'absolute', inset: 0 }} />}
    </div>
  );
}

function getYear(emp, y) { return (emp.years && emp.years[y]) || null; }

// Stacked bar: taken (sage) + planned (amber hatch) over the year's total
function StackBar({ rec, height = 8 }) {
  if (!rec) return null;
  const total = Math.max(rec.startedWith, rec.taken + rec.planned, 1);
  const tk = (rec.taken / total) * 100;
  const pl = (rec.planned / total) * 100;
  return (
    <div style={{ display: 'flex', height, borderRadius: 99, overflow: 'hidden',
      background: '#e6efe2', width: '100%' }}>
      <div style={{ width: tk + '%', background: 'var(--sage-deep)' }} title={`Brukt: ${nDays(rec.taken)}`}></div>
      <div title={`Planlagt: ${nDays(rec.planned)}`} style={{
        width: pl + '%',
        backgroundImage: 'repeating-linear-gradient(45deg, var(--plan) 0 4px, #d9ad65 4px 8px)',
      }}></div>
    </div>
  );
}

// Circular ring (taken + planned arcs, hole shows available)
function Ring({ rec, size = 108 }) {
  if (!rec) return (
    <div style={{ width: size, height: size, borderRadius: '50%', background: '#eee5d2',
      display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--slate-soft)' }}>–</div>
  );
  const total = Math.max(rec.startedWith, rec.taken + rec.planned, 1);
  const tkDeg = (rec.taken / total) * 360;
  const plDeg = (rec.planned / total) * 360;
  const ring = `conic-gradient(var(--sage-deep) 0 ${tkDeg}deg, var(--plan) ${tkDeg}deg ${tkDeg + plDeg}deg, #e6efe2 ${tkDeg + plDeg}deg 360deg)`;
  const hole = size - 26;
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', background: ring,
      display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
      <div style={{ width: hole, height: hole, borderRadius: '50%', background: 'var(--card)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', lineHeight: 1 }}>
        <div style={{ fontFamily: '"PT Serif",serif', fontWeight: 700, fontSize: size * 0.3, color: 'var(--ink)' }}>{nDays(rec.available)}</div>
        <div style={{ fontSize: 10.5, color: 'var(--slate-soft)', marginTop: 3, textTransform: 'uppercase', letterSpacing: '.6px' }}>igjen</div>
      </div>
    </div>
  );
}

function Legend() {
  return (
    <div style={{ display: 'flex', gap: 18, alignItems: 'center', fontSize: 13, color: 'var(--slate-soft)' }}>
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
        <i style={{ width: 12, height: 12, borderRadius: 3, background: 'var(--sage-deep)' }}></i>Brukt</span>
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
        <i style={{ width: 12, height: 12, borderRadius: 3, backgroundImage: 'repeating-linear-gradient(45deg, var(--plan) 0 3px, #d9ad65 3px 6px)' }}></i>Planlagt</span>
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
        <i style={{ width: 12, height: 12, borderRadius: 3, background: '#e6efe2' }}></i>Tilgjengelig</span>
    </div>
  );
}

// ── Summary band ─────────────────────────────
function SummaryBand({ rows }) {
  const withYear = rows.filter(r => r.rec);
  const totalAvail = withYear.reduce((s, r) => s + r.rec.available, 0);
  const totalPlanned = withYear.reduce((s, r) => s + r.rec.planned, 0);
  const noSummer = withYear.filter(r => !r.rec.entries.some(e =>
    e.status === 'planned' && [5, 6, 7].includes(FMT.parse(e.date).getMonth()))).length;
  const stat = (big, label, accent) => (
    <div style={{ flex: 1, padding: '4px 0' }}>
      <div style={{ fontFamily: '"PT Serif",serif', fontWeight: 700, fontSize: 30, color: accent || 'var(--ink)', lineHeight: 1 }}>{big}</div>
      <div style={{ fontSize: 13.5, color: 'var(--slate-soft)', marginTop: 6 }}>{label}</div>
    </div>
  );
  return (
    <div style={{ display: 'flex', gap: 0, background: 'var(--card)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius)', padding: '18px 26px', marginBottom: 26, boxShadow: 'var(--shadow)' }}>
      {stat(rows.length, 'ansatte i oversikten')}
      {stat(nDays(totalAvail), 'feriedager tilgjengelig nå')}
      {stat(nDays(totalPlanned), 'dager planlagt resten av året', 'var(--plan)')}
      {stat(noSummer, 'uten planlagt sommerferie', noSummer > 0 ? 'var(--danger)' : 'var(--ink)')}
    </div>
  );
}

// ── Toolbar (search) ─────────────────────────
function Toolbar({ q, setQ }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 22 }}>
      <div style={{ position: 'relative', flex: 1, maxWidth: 520 }}>
        <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--slate-soft)' }}>⌕</span>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Søk etter ansatt"
          style={{ width: '100%', padding: '11px 14px 11px 38px', border: '1px solid var(--border-strong)',
            borderRadius: 'var(--radius)', background: 'var(--card)', color: 'var(--slate)', fontSize: 15, fontFamily: 'inherit' }} />
      </div>
    </div>
  );
}

// ── Direction A: Table ───────────────────────
function OverviewTable({ rows, onOpen, density }) {
  const [sort, setSort] = React.useState({ key: 'name', dir: 1 });
  const pad = density === 'compact' ? '12px 18px' : density === 'comfy' ? '22px 18px' : '17px 18px';
  const sorted = [...rows].sort((a, b) => {
    let av, bv;
    if (sort.key === 'name') { av = a.emp.name; bv = b.emp.name; return av.localeCompare(bv, 'nb') * sort.dir; }
    av = a.rec ? a.rec[sort.key] : -1; bv = b.rec ? b.rec[sort.key] : -1;
    return (av - bv) * sort.dir;
  });
  const th = (key, label, align) => (
    <th onClick={() => setSort(s => ({ key, dir: s.key === key ? -s.dir : 1 }))}
      style={{ textAlign: align || 'left', padding: '0 18px 12px', fontSize: 12.5, fontWeight: 700,
        color: 'var(--slate-soft)', textTransform: 'uppercase', letterSpacing: '.7px', cursor: 'pointer', whiteSpace: 'nowrap', userSelect: 'none' }}>
      {label}{sort.key === key ? (sort.dir === 1 ? ' ↑' : ' ↓') : ''}
    </th>
  );
  return (
    <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', boxShadow: 'var(--shadow)' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead><tr style={{ borderBottom: '1px solid var(--border)' }}>
          <th style={{ padding: '16px 18px 12px' }}></th>
          {th('name', 'Ansatt')}
          {th('available', 'Tilgjengelig nå', 'right')}
          {th('taken', 'Brukt i år', 'right')}
          {th('planned', 'Planlagt i år', 'right')}
          {th('transferred', 'Overført fra i fjor', 'right')}
        </tr></thead>
        <tbody>
          {sorted.map((r, i) => (
            <tr key={r.emp.id} onClick={() => onOpen(r.emp.id)}
              style={{ borderTop: i ? '1px solid var(--border)' : 'none', cursor: 'pointer' }}
              onMouseEnter={e => e.currentTarget.style.background = '#f4ecda'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
              <td style={{ padding: pad, width: 56 }}><Avatar emp={r.emp} size={38} /></td>
              <td style={{ padding: pad }}>
                <div style={{ fontWeight: 700, color: 'var(--ink)', fontSize: 16 }}>{r.emp.name}</div>
                <div style={{ fontSize: 13, color: 'var(--slate-soft)', marginTop: 2 }}>{r.emp.role}</div>
              </td>
              <td style={{ padding: pad, textAlign: 'right' }}>
                {r.rec
                  ? <span style={{ fontFamily: '"PT Serif",serif', fontWeight: 700, fontSize: 24, color: r.rec.available <= 5 ? 'var(--danger)' : 'var(--ink)' }}>{nDays(r.rec.available)}</span>
                  : <span style={{ color: 'var(--slate-soft)' }}>–</span>}
              </td>
              <td style={{ padding: pad, textAlign: 'right', color: 'var(--slate)', fontSize: 16 }}>{r.rec ? nDays(r.rec.taken) : '–'}</td>
              <td style={{ padding: pad, textAlign: 'right' }}>
                {r.rec && r.rec.planned > 0
                  ? <span className="pill plan">{nDays(r.rec.planned)}</span>
                  : <span style={{ color: 'var(--slate-soft)' }}>–</span>}
              </td>
              <td style={{ padding: pad, textAlign: 'right', fontSize: 16 }}>
                {r.rec && r.rec.transferred > 0
                  ? <span style={{ color: 'var(--slate)' }}>+{nDays(r.rec.transferred)}</span>
                  : <span style={{ color: 'var(--slate-soft)' }}>{r.rec ? '0' : '–'}</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Direction B: Card grid ───────────────────
function OverviewCards({ rows, onOpen }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(248px, 1fr))', gap: 20 }}>
      {rows.map(r => (
        <div key={r.emp.id} onClick={() => onOpen(r.emp.id)}
          style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)',
            padding: '24px 22px 18px', cursor: 'pointer', boxShadow: 'var(--shadow)', transition: 'border-color .15s, transform .15s' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--sage)'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'none'; }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20 }}>
            <Avatar emp={r.emp} size={46} />
            <div style={{ minWidth: 0 }}>
              <div style={{ fontFamily: '"PT Serif",serif', fontWeight: 700, fontSize: 18, color: 'var(--ink)', lineHeight: 1.15 }}>{r.emp.name}</div>
              <div style={{ fontSize: 12.5, color: 'var(--slate-soft)', marginTop: 3 }}>{r.emp.role}</div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
            <Ring rec={r.rec} size={96} />
            <div style={{ flex: 1 }}>
              <Row label="Brukt i år" val={r.rec ? nDays(r.rec.taken) : '–'} dot="var(--sage-deep)" />
              <Row label="Planlagt i år" val={r.rec ? nDays(r.rec.planned) : '–'} dot="var(--plan)" plan />
              <Row label="Overført i fjor" val={r.rec ? (r.rec.transferred > 0 ? '+' + nDays(r.rec.transferred) : '0') : '–'} dot="#cfe0c6" />
            </div>
          </div>
          <div style={{ borderTop: '1px solid var(--border)', marginTop: 16, paddingTop: 12, textAlign: 'right' }}>
            <span style={{ color: 'var(--gold)', fontSize: 13.5, fontWeight: 700, letterSpacing: '.4px' }}>GÅ TIL →</span>
          </div>
        </div>
      ))}
    </div>
  );
}
function Row({ label, val, dot, plan }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '3px 0' }}>
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 13.5, color: 'var(--slate-soft)' }}>
        <i style={{ width: 9, height: 9, borderRadius: 2, background: dot, border: plan ? '1px solid var(--plan)' : 'none' }}></i>{label}</span>
      <b style={{ color: 'var(--ink)', fontSize: 14.5 }}>{val}</b>
    </div>
  );
}

function OverviewPage({ onOpen, t }) {
  const [q, setQ] = React.useState('');
  const year = TODAY.getFullYear();

  const rows = React.useMemo(() => window.FERIE_DATA
    .filter(e => e.name.toLowerCase().includes(q.toLowerCase()))
    .map(e => ({ emp: e, rec: getYear(e, year) })), [q, year]);

  return (
    <div className="page">
      <h1 className="pagetitle">Ferie</h1>
      <div className="subtitle">Feriedager for alle ansatte i {year}. Klikk en ansatt for detaljer.</div>
      <div style={{ height: 28 }}></div>
      <Toolbar q={q} setQ={setQ} />
      <SummaryBand rows={rows} />
      {t.overviewLayout === 'kort' && <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 14 }}><Legend /></div>}
      {t.overviewLayout === 'kort'
        ? <OverviewCards rows={rows} onOpen={onOpen} />
        : <OverviewTable rows={rows} onOpen={onOpen} density={t.density} />}
    </div>
  );
}

Object.assign(window, { Avatar, Ring, StackBar, Legend, nDays, getYear, OverviewPage });
