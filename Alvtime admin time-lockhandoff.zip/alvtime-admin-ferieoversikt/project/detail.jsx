/* Ferie — per-employee detail. Year selector, hero breakdown, expandable periods. */

const DFMT = window.FERIE_FMT;
const DTODAY = window.FERIE_TODAY;
const { Avatar: DAvatar, nDays: dNDays, getYear: dGetYear } = window;

// Group consecutive workday entries into vacation periods
function groupPeriods(entries) {
  const g = [];
  for (const e of entries) {
    const last = g[g.length - 1];
    const prev = last && last.days[last.days.length - 1];
    const gapDays = prev ? (DFMT.parse(e.date) - DFMT.parse(prev.date)) / 86400000 : 99;
    if (last && gapDays <= 4 && last.note === e.note) last.days.push(e);
    else g.push({ note: e.note, days: [e] });
  }
  return g.map(p => {
    const from = p.days[0].date, to = p.days[p.days.length - 1].date;
    const count = p.days.reduce((s, d) => s + (d.half ? 0.5 : 1), 0);
    const st = new Set(p.days.map(d => d.status));
    return { ...p, from, to, count, status: st.size > 1 ? 'mixed' : [...st][0] };
  });
}

function rangeLabel(from, to) {
  const a = DFMT.parse(from), b = DFMT.parse(to);
  if (from === to) return DFMT.long(a);
  const sameMonth = a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
  if (sameMonth) return `${a.getDate()}.–${b.getDate()}. ${DFMT.MONTHS[b.getMonth()]} ${b.getFullYear()}`;
  return `${a.getDate()}. ${DFMT.MONTHS_SHORT[a.getMonth()]} – ${b.getDate()}. ${DFMT.MONTHS_SHORT[b.getMonth()]} ${b.getFullYear()}`;
}

function StatTile({ label, value, sub, accent, big }) {
  return (
    <div style={{ flex: 1, padding: '18px 20px', background: 'var(--card)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius)', boxShadow: 'var(--shadow)' }}>
      <div style={{ fontSize: 13, color: 'var(--slate-soft)', textTransform: 'uppercase', letterSpacing: '.6px', fontWeight: 700 }}>{label}</div>
      <div style={{ fontFamily: '"PT Serif",serif', fontWeight: 700, fontSize: big ? 44 : 34, color: accent || 'var(--ink)', lineHeight: 1.05, marginTop: 8 }}>{value}</div>
      {sub && <div style={{ fontSize: 12.5, color: 'var(--slate-soft)', marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

// Horizontal allocation bar: startedWith split into taken / planned / free
function AllocationBar({ rec }) {
  const total = Math.max(rec.startedWith, rec.taken + rec.planned, 1);
  const seg = (val, bg, label, hatch) => {
    if (val <= 0) return null;
    const w = (val / total) * 100;
    return (
      <div style={{ width: w + '%', minWidth: w > 0 ? 2 : 0 }}>
        <div style={{ height: 16, background: hatch ? undefined : bg,
          backgroundImage: hatch ? 'repeating-linear-gradient(45deg, var(--plan) 0 5px, #d9ad65 5px 10px)' : undefined,
          borderRadius: 3 }}></div>
        {w > 10 && <div style={{ fontSize: 12, color: 'var(--slate-soft)', marginTop: 6, whiteSpace: 'nowrap' }}>{label} <b style={{ color: 'var(--ink)' }}>{dNDays(val)}</b></div>}
      </div>
    );
  };
  return (
    <div>
      <div style={{ display: 'flex', gap: 4 }}>
        {seg(rec.taken, 'var(--sage-deep)', 'Brukt')}
        {seg(rec.planned, null, 'Planlagt', true)}
        {seg(Math.max(rec.free, 0), '#dfe9d7', 'Tilgjengelig')}
      </div>
    </div>
  );
}

function PeriodRow({ p, defaultOpen }) {
  const [open, setOpen] = React.useState(!!defaultOpen);
  const planned = p.status === 'planned';
  const mixed = p.status === 'mixed';
  return (
    <div style={{ borderBottom: '1px solid var(--border)' }}>
      <div onClick={() => setOpen(o => !o)} style={{ display: 'flex', alignItems: 'center', gap: 16,
        padding: '16px 8px', cursor: 'pointer' }}
        onMouseEnter={e => e.currentTarget.style.background = '#f4ecda'}
        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
        <span style={{ width: 18, color: 'var(--slate-soft)', transition: 'transform .15s', transform: open ? 'rotate(90deg)' : 'none' }}>▸</span>
        <span className={`pill ${planned ? 'plan' : 'taken'}`} style={{ minWidth: 78, justifyContent: 'center' }}>
          {planned ? 'Planlagt' : mixed ? 'Pågår' : 'Brukt'}
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 700, color: 'var(--ink)', fontSize: 16 }}>{p.note || 'Ferie'}</div>
          <div style={{ fontSize: 13.5, color: 'var(--slate-soft)', marginTop: 2 }}>{rangeLabel(p.from, p.to)}</div>
        </div>
        <div style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
          <span style={{ fontFamily: '"PT Serif",serif', fontWeight: 700, fontSize: 20, color: 'var(--ink)' }}>{dNDays(p.count)}</span>
          <span style={{ fontSize: 13, color: 'var(--slate-soft)', marginLeft: 5 }}>{p.count === 1 ? 'dag' : 'dager'}</span>
        </div>
      </div>
      {open && (
        <div style={{ padding: '4px 8px 16px 52px', background: '#fbf6ec' }}>
          {p.days.map(d => {
            const dt = DFMT.parse(d.date);
            const isPlan = d.status === 'planned';
            return (
              <div key={d.date} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '8px 0', borderTop: '1px solid var(--border)' }}>
                <i style={{ width: 9, height: 9, borderRadius: '50%', flex: '0 0 auto',
                  background: isPlan ? 'transparent' : 'var(--sage-deep)', border: isPlan ? '2px solid var(--plan)' : 'none' }}></i>
                <div style={{ width: 92, fontSize: 14, color: 'var(--slate)', textTransform: 'capitalize' }}>{DFMT.weekday(dt)}</div>
                <div style={{ width: 150, fontSize: 14, color: 'var(--ink)', fontWeight: 700 }}>{DFMT.medium(dt)}</div>
                <div style={{ flex: 1, fontSize: 13, color: 'var(--slate-soft)' }}>
                  {d.half && <span className="pill" style={{ background: '#eee5d2', color: 'var(--slate)', marginRight: 8 }}>½ dag</span>}
                  {d.registered ? `Registrert ${DFMT.medium(DFMT.parse(d.registered))}` : 'Registrert'}
                </div>
                {isPlan
                  ? <span style={{ fontSize: 12.5, color: 'var(--plan)', fontWeight: 700 }}>Planlagt</span>
                  : <span style={{ fontSize: 12.5, color: 'var(--sage-deep)', fontWeight: 700 }}>Brukt</span>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function DetailPage({ empId, onBack }) {
  const emp = window.FERIE_DATA.find(e => e.id === empId);
  const year = DTODAY.getFullYear();
  const rec = dGetYear(emp, year);
  const periods = React.useMemo(() => rec ? groupPeriods(rec.entries) : [], [rec]);
  const upcomingIdx = periods.findIndex(p => p.status !== 'taken');

  return (
    <div className="page">
      <button className="back" onClick={onBack}>←</button>
      <div style={{ display: 'flex', alignItems: 'center', gap: 22, marginTop: 4, marginBottom: 8 }}>
        <DAvatar emp={emp} size={78} />
        <div>
          <h1 style={{ fontSize: 'clamp(32px, 3.4vw, 46px)', lineHeight: 1.05 }}>{emp.name}</h1>
          <div style={{ color: 'var(--slate-soft)', fontSize: 16, marginTop: 8 }}>{emp.role} · Ansattnummer {emp.id}</div>
        </div>
      </div>

      <div style={{ margin: '22px 0 22px', fontSize: 14, color: 'var(--slate-soft)' }}>
        Ferieår <b style={{ color: 'var(--ink)' }}>{year}</b> · per {DFMT.long(DTODAY)}
      </div>

      {!rec ? (
        <div style={{ padding: 40, textAlign: 'center', color: 'var(--slate-soft)', background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)' }}>
          Ingen ferie registrert for {year}.
        </div>
      ) : (
        <>
          {/* Hero stats — the four key numbers */}
          <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
            <StatTile label="Tilgjengelig nå" value={dNDays(rec.available)} sub="feriedager igjen" accent={rec.available <= 5 ? 'var(--danger)' : 'var(--sage-deep)'} big />
            <StatTile label="Brukt i år" value={dNDays(rec.taken)} sub="dager avviklet" />
            <StatTile label="Planlagt i år" value={dNDays(rec.planned)} sub="dager fremover" accent={rec.planned > 0 ? 'var(--plan)' : undefined} />
            <StatTile label="Overført fra i fjor" value={rec.transferred > 0 ? '+' + dNDays(rec.transferred) : '0'} sub={rec.transferred > 0 ? 'lagt til kvoten' : 'ingen overført'} />
          </div>

          {/* Allocation bar */}
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)',
            padding: '20px 24px', marginBottom: 30, boxShadow: 'var(--shadow)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
              <div style={{ fontSize: 13.5, color: 'var(--slate-soft)', fontWeight: 700 }}>Fordeling av {dNDays(rec.startedWith)} feriedager i {year}</div>
              {window.Legend && <window.Legend />}
            </div>
            <AllocationBar rec={rec} />
          </div>

          {/* Periods */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
            <h2 style={{ fontSize: 24 }}>Registrerte feriedager</h2>
            <span style={{ fontSize: 13.5, color: 'var(--slate-soft)' }}>{rec.entries.length} {rec.entries.length === 1 ? 'dag' : 'dager'} i {periods.length} {periods.length === 1 ? 'periode' : 'perioder'}</span>
          </div>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)',
            boxShadow: 'var(--shadow)', overflow: 'hidden', marginTop: 12 }}>
            {periods.length === 0
              ? <div style={{ padding: 28, color: 'var(--slate-soft)' }}>Ingen feriedager registrert i {year}.</div>
              : periods.map((p, i) => <PeriodRow key={i} p={p} defaultOpen={i === upcomingIdx} />)}
          </div>
        </>
      )}
    </div>
  );
}

window.DetailPage = DetailPage;
