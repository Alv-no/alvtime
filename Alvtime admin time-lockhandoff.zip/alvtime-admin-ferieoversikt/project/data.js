/* Alvtime — Ferie sample data.
   In production these numbers come from the backend; here we synthesize a
   realistic Norwegian dataset. "Today" is fixed so the prototype is stable. */
(function () {
  const TODAY = new Date(2026, 5, 10); // 10. juni 2026
  window.FERIE_TODAY = TODAY;

  const WEEKDAYS = ['Søndag', 'Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag'];
  const MONTHS = ['januar', 'februar', 'mars', 'april', 'mai', 'juni', 'juli',
    'august', 'september', 'oktober', 'november', 'desember'];
  const MONTHS_SHORT = ['jan', 'feb', 'mar', 'apr', 'mai', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'des'];

  // Norwegian public holidays we skip when expanding ranges (so day counts are honest)
  const HOLIDAYS = new Set([
    // 2024
    '2024-01-01', '2024-03-28', '2024-03-29', '2024-04-01', '2024-05-01', '2024-05-09', '2024-05-17', '2024-05-20', '2024-12-25', '2024-12-26',
    // 2025
    '2025-01-01', '2025-04-17', '2025-04-18', '2025-04-21', '2025-05-01', '2025-05-17', '2025-05-29', '2025-06-09', '2025-12-25', '2025-12-26',
    // 2026
    '2026-01-01', '2026-04-02', '2026-04-03', '2026-04-06', '2026-05-01', '2026-05-14', '2026-05-17', '2026-05-25', '2026-12-25', '2026-12-26',
  ]);

  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parse(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }

  window.FERIE_FMT = {
    WEEKDAYS, MONTHS, MONTHS_SHORT, iso, parse,
    long(d) { return d.getDate() + '. ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear(); },
    medium(d) { return pad(d.getDate()) + '. ' + MONTHS_SHORT[d.getMonth()] + '. ' + d.getFullYear(); },
    weekday(d) { return WEEKDAYS[d.getDay()]; },
    dayMonth(d) { return d.getDate() + '. ' + MONTHS_SHORT[d.getMonth()] + '.'; },
  };

  // Expand inclusive date ranges into individual workday entries (skip weekends + holidays)
  function expand(ranges) {
    const out = [];
    for (const r of ranges) {
      const start = parse(r.from), end = parse(r.to || r.from);
      for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        const day = d.getDay();
        if (day === 0 || day === 6) continue;        // weekend
        if (HOLIDAYS.has(iso(d))) continue;            // public holiday
        out.push({
          date: iso(d),
          half: false,
          note: r.note || null,
          registered: r.registered || null,
        });
      }
    }
    // half days (e.g. a single afternoon)
    return out;
  }

  // Build a year record from authored ranges
  function year(startedWith, ranges, opts) {
    opts = opts || {};
    let entries = expand(ranges);
    // attach explicit half-days
    (opts.halfDays || []).forEach(h => entries.push({ date: h.date, half: true, note: h.note || null, registered: h.registered || null }));
    entries.sort((a, b) => a.date.localeCompare(b.date));
    let taken = 0, planned = 0;
    for (const e of entries) {
      const isPast = parse(e.date) <= TODAY;
      e.status = isPast ? 'taken' : 'planned';
      const amt = e.half ? 0.5 : 1;
      if (isPast) taken += amt; else planned += amt;
    }
    return {
      startedWith,
      entries,
      taken,
      planned,
      transferred: opts.transferred || 0,                   // overført fra i fjor
      available: +(startedWith - taken).toFixed(1),        // available right now
      free: +(startedWith - taken - planned).toFixed(1),    // free to plan after commitments
      carriedFrom: opts.carriedFrom || null,                // explanation of starting balance
    };
  }

  // ── Employees ───────────────────────────────────────────────────────────────
  const E = [];
  function emp(id, name, init, role, opts) { E.push(Object.assign({ id, name, initials: init, role }, opts)); }

  emp(81, 'Anders Norman', 'AN', 'Senior konsulent', {
    photo: true,
    years: {
      2026: year(28, [
        { from: '2026-02-23', to: '2026-02-27', note: 'Vinterferie', registered: '2026-01-12' },
        { from: '2026-07-06', to: '2026-07-24', note: 'Sommerferie', registered: '2026-03-30' },
        { from: '2026-10-05', to: '2026-10-09', note: 'Høstferie', registered: '2026-05-02' },
      ], { carriedFrom: '25 nye + 3 overført fra 2025', transferred: 3 }),
      2025: year(26, [
        { from: '2025-03-03', to: '2025-03-07', note: 'Vinterferie' },
        { from: '2025-07-07', to: '2025-07-25', note: 'Sommerferie' },
      ], { carriedFrom: '25 nye + 1 overført' }),
      2024: year(25, [
        { from: '2024-07-08', to: '2024-07-26', note: 'Sommerferie' },
        { from: '2024-12-23', to: '2024-12-31', note: 'Romjul' },
      ]),
    },
  });

  emp(12, 'Adrian Brenne', 'AB', 'Utvikler', {
    years: {
      2026: year(25, [
        { from: '2026-04-13', to: '2026-04-17', note: 'Påskeuke', registered: '2026-02-01' },
        { from: '2026-08-03', to: '2026-08-14', note: 'Sommerferie', registered: '2026-04-20' },
      ]),
      2025: year(25, [{ from: '2025-07-14', to: '2025-08-01', note: 'Sommerferie' }]),
    },
  });

  emp(34, 'Aleksander Walde', 'AW', 'Designer', {
    years: {
      2026: year(30, [
        { from: '2026-01-02', to: '2026-01-03', note: 'Forlenget nyttår', registered: '2025-12-01' },
        { from: '2026-06-29', to: '2026-07-17', note: 'Sommerferie', registered: '2026-02-14' },
      ], { carriedFrom: '25 nye + 5 overført (max)', transferred: 5 }),
      2025: year(25, [{ from: '2025-06-23', to: '2025-07-11', note: 'Sommerferie' }]),
    },
  });

  emp(7, 'Alexander Johansen Ohrt', 'AJ', 'Senior utvikler', {
    years: {
      2026: year(25, [
        { from: '2026-02-16', to: '2026-02-20', note: 'Vinterferie', registered: '2026-01-05' },
        { from: '2026-07-13', to: '2026-07-31', note: 'Sommerferie', registered: '2026-03-11' },
        { from: '2026-12-21', to: '2026-12-31', note: 'Romjul', registered: '2026-05-29' },
      ]),
      2025: year(27, [{ from: '2025-07-21', to: '2025-08-08', note: 'Sommerferie' }], { carriedFrom: '25 nye + 2 overført' }),
    },
  });

  emp(55, 'Anders Smedstuen Lund', 'AS', 'Konsulent', {
    years: {
      2026: year(25, [
        { from: '2026-05-18', to: '2026-05-22', note: 'Langhelg', registered: '2026-03-02' },
      ], { halfDays: [{ date: '2026-06-19', note: 'Halv dag', registered: '2026-06-01' }] }),
    },
  });

  emp(63, 'Andreas Aarrestad', 'AA', 'Prosjektleder', {
    years: {
      2026: year(22, [
        { from: '2026-01-12', to: '2026-01-23', note: 'Skiferie', registered: '2025-11-20' },
        { from: '2026-03-30', to: '2026-04-03', note: 'Påske', registered: '2026-01-15' },
        { from: '2026-06-22', to: '2026-07-10', note: 'Sommerferie', registered: '2026-02-28' },
      ], { carriedFrom: '25 nye − 3 forskuddstrukket' }),
      2025: year(25, [{ from: '2025-07-01', to: '2025-07-18', note: 'Sommerferie' }]),
    },
  });

  emp(91, 'Andreas Kristoffer Johansen', 'AK', 'Senior konsulent', {
    photo: true,
    years: {
      2026: year(26, [
        { from: '2026-07-20', to: '2026-08-07', note: 'Sommerferie', registered: '2026-04-09' },
      ], { carriedFrom: '25 nye + 1 overført', transferred: 1 }),
    },
  });

  emp(28, 'Andreas Strand', 'AS', 'Utvikler', {
    years: {
      2026: year(25, [
        { from: '2026-02-09', to: '2026-02-13', note: 'Vinterferie', registered: '2026-01-08' },
        { from: '2026-04-07', to: '2026-04-10', note: 'Etter påske', registered: '2026-02-22' },
        { from: '2026-07-27', to: '2026-08-14', note: 'Sommerferie', registered: '2026-05-15' },
        { from: '2026-11-02', to: '2026-11-06', note: 'Høstpause', registered: '2026-06-02' },
      ]),
    },
  });

  emp(44, 'Angela Maiken Johnsen', 'AM', 'Forretningsutvikler', {
    years: {
      2026: year(24, [
        { from: '2026-06-15', to: '2026-06-26', note: 'Sommerferie', registered: '2026-03-18' },
        { from: '2026-09-28', to: '2026-10-02', note: 'Høstferie', registered: '2026-05-20' },
      ]),
      2025: year(25, [{ from: '2025-08-04', to: '2025-08-22', note: 'Sommerferie' }]),
    },
  });

  emp(19, 'Anna Jansdatter Bjørgo', 'AJ', 'Designer', {
    years: {
      2026: year(25, [
        { from: '2026-07-06', to: '2026-07-31', note: 'Sommerferie', registered: '2026-01-30' },
      ]),
    },
  });

  emp(72, 'Arturo Opsetmoen Amador', 'AO', 'Utvikler', {
    years: {
      2026: year(25, []),
    },
  });

  emp(38, 'Birgitte Sønderland', 'BS', 'Konsulent', {
    years: {
      2026: year(27, [
        { from: '2026-03-09', to: '2026-03-13', note: 'Vinterferie', registered: '2026-01-20' },
        { from: '2026-06-29', to: '2026-07-17', note: 'Sommerferie', registered: '2026-02-10' },
      ], { carriedFrom: '25 nye + 2 overført', transferred: 2 }),
    },
  });

  emp(50, 'Camilla Dahl Nygård', 'CN', 'Prosjektleder', {
    photo: true,
    years: {
      2026: year(25, [
        { from: '2026-05-04', to: '2026-05-08', note: 'Langhelg', registered: '2026-03-15' },
        { from: '2026-08-10', to: '2026-08-28', note: 'Sommerferie', registered: '2026-04-25' },
      ]),
    },
  });

  emp(66, 'Eivind Haugland', 'EH', 'Senior utvikler', {
    years: {
      2026: year(23, [
        { from: '2026-01-05', to: '2026-01-09', note: 'Forlenget jul', registered: '2025-11-30' },
        { from: '2026-07-13', to: '2026-08-07', note: 'Sommerferie', registered: '2026-03-04' },
      ], { carriedFrom: '25 nye − 2 forskuddstrukket' }),
    },
  });

  // Sort alphabetically like the existing "Alver" listing
  E.sort((a, b) => a.name.localeCompare(b.name, 'nb'));
  window.FERIE_DATA = E;
})();
