/* Alvtime adminpanel — app shell, routing, Tweaks. */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "overviewLayout": "tabell",
  "density": "regular",
  "accent": ["#9dac86", "#7c9067", "#bb8a3c"],
  "showPlanned": true
}/*EDITMODE-END*/;

const NAV = ['Forside', 'Ansatte', 'Kunder', 'Ferie', 'Timelås'];

function App() {
  const [t, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const [route, setRoute] = React.useState({ name: 'Timelås', empId: null });

  // apply accent palette to CSS vars
  React.useEffect(() => {
    const [sage, deep, plan] = t.accent || [];
    const r = document.documentElement.style;
    if (sage) r.setProperty('--sage', sage);
    if (deep) r.setProperty('--sage-deep', deep);
    if (plan) { r.setProperty('--plan', plan); }
  }, [t.accent]);

  const openEmp = (id) => { setRoute({ name: 'Ferie', empId: id }); document.querySelector('.main').scrollTop = 0; };
  const goNav = (name) => setRoute({ name, empId: null });

  let content;
  if (route.name === 'Ferie' && route.empId != null) {
    content = <window.DetailPage empId={route.empId} onBack={() => goNav('Ferie')} />;
  } else if (route.name === 'Ferie') {
    content = <window.OverviewPage onOpen={openEmp} t={t} />;
  } else if (route.name === 'Timelås') {
    content = <window.LockPage />;
  } else {
    content = <Placeholder name={route.name} />;
  }

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <button className="burger" title="Meny">☰</button>
          <span className="logo">Alvtime adminpanel</span>
        </div>
        <div className="who">
          <b>Hei, Pål Bøckmann!</b>
          <a href="#">Logg ut</a>
        </div>
      </header>
      <div className="body">
        <nav className="sidebar">
          {NAV.map(n => (
            <span key={n} className={'navitem' + (n === route.name ? ' active' : '')} onClick={() => goNav(n)}>{n}</span>
          ))}
        </nav>
        <main className="main">{content}</main>
      </div>

      <window.TweaksPanel>
        <window.TweakSection label="Oversikt" />
        <window.TweakRadio label="Visning" value={t.overviewLayout}
          options={[{ value: 'tabell', label: 'Tabell' }, { value: 'kort', label: 'Kort' }]}
          onChange={v => setTweak('overviewLayout', v)} />
        <window.TweakRadio label="Tetthet" value={t.density}
          options={['compact', 'regular', 'comfy']}
          onChange={v => setTweak('density', v)} />
        <window.TweakSection label="Farger" />
        <window.TweakColor label="Aksent" value={t.accent}
          options={[['#9dac86', '#7c9067', '#bb8a3c'], ['#7ea8a0', '#4f7d77', '#c98a3c'], ['#a9a36a', '#827b45', '#b0623f']]}
          onChange={v => setTweak('accent', v)} />
      </window.TweaksPanel>
    </div>
  );
}

function Placeholder({ name }) {
  return (
    <div className="page">
      <h1 className="pagetitle">{name === 'Forside' ? 'Velkommen til Alvtime adminpanel!' : name}</h1>
      <div className="subtitle">
        {name === 'Forside'
          ? 'Velg hva du vil administrere i panelet til venstre.'
          : `«${name}» er ikke en del av denne prototypen. Velg «Ferie» for ferieoversikten.`}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
